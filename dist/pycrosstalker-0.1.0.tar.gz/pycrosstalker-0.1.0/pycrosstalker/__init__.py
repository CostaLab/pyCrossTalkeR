__version__ = "0.0.0.1"
__author__ = 'James Nagai'
__credits__ = 'Institute for Computational Genomics'

import pycrosstalker.tools as tl
import pycrosstalker.plots as pl


#Atfan helped to translate some of the code